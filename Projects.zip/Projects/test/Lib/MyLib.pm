package MyLib;
use strict;

sub Test {
  print "MyLib - Test Ok!\n";
}

1; # сообщает интерпретатору, что все ОК