#!C:\Strawberry\perl\bin\perl.exe

use Data::Dumper;
use warnings;
use strict;
use lib 'C:\Strawberry\Projects\test\Lib'; #путь к папке
use MyLib; #либа


MyLib::Test();