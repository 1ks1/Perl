#!C:\perl\bin\perl.exe

use Data::Dumper;
use warnings;
use strict;
use lib 'C:\Strawberry\Projects\DbCon\Lib'; #FOR HOME WIN PC
use Dbcon;

##############################
#CONFIG
#my $host = '127.0.0.1';
#my $passwd = 'user11';
#my $user = 'user11';
my $host = '127.0.0.1:3307'; #дома
my $user = 'root'; #username
my $passwd = 'usbw'; #password
##############################
my $dbname = 'user11'; #databasename
my $driver = 'DBI:mysql';

##############################

Dbcon->Test();


my $connector = Dbcon->new($driver,$host,$dbname,$user,$passwd);


my $sql = "select * from MY_TEST";
my @result =  $connector->select($sql);
foreach my $v (@result)
    {
            print "$v{name}\n";
     }
#print Dumper(@result);


#my $insert_sql = "INSERT INTO MY_TEST (id, name) VALUES (?, ?)";
#my $insertresult = $connector->do($insert_sql,('inserfromscript', 'tset', '1000'));
#print Dumper($insertresult);

